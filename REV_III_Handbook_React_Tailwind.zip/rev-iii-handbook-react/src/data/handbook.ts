export const chapters=[
{id:'logic',title:'Revisionslogik och assertions',slides:'Slides 4–16',summary:'Risk, assertion, revisionsrespons, revisionsbevis och slutsats.',rules:'ISA 315 · ISA 330'},
{id:'risk',title:'Riskbedömning och revisionsstrategi',slides:'Slides 118–131',summary:'Identifiera och bedöma RMM samt anpassa nature, timing and extent.',rules:'ISA 240 · ISA 315 · ISA 320 · ISA 330'},
{id:'intangibles',title:'Immateriella anläggningstillgångar',slides:'Slides 17–45',summary:'Aktivering, utvecklingsfas, nyttjandeperiod och nedskrivning.',rules:'ISA 540'},
{id:'tangibles',title:'Materiella anläggningstillgångar',slides:'Slides 46–70',summary:'Existens, ägande, utrangering och avskrivningar.',rules:'ISA 500 · ISA 540'},
{id:'financial',title:'Finansiella anläggningstillgångar',slides:'Slides 71–82',summary:'Värdering, nedskrivning och klassificering.',rules:'ISA 540'},
{id:'ada',title:'Audit Data Analytics',slides:'Slides 83–100',summary:'Planera, verifiera data, analysera och dokumentera.',rules:'ISA 500 · ISA 520'},
{id:'revenue',title:'Intäkter och fraud',slides:'Slides 101–145, 226–239',summary:'Intäktsredovisning, fraudpresumtion och revisionsrespons.',rules:'ISA 240 · ISA 315 · ISA 330 · ISA 520'},
{id:'inventory',title:'Varulager',slides:'Slides 147–184',summary:'Inventering, pristest, NRV och inkurans.',rules:'ISA 501 · ISA 510'},
{id:'assurance',title:'Övriga bestyrkandeuppdrag',slides:'Slides 189–198',summary:'Översiktlig granskning, bestyrkande och AUP.',rules:'ISRE · ISAE · ISRS 4400'},
{id:'practice',title:'Revision i praktiken',slides:'Slides 201–220',summary:'Alternativa åtgärder och dokumentation.',rules:'ISA 500'}];
export const terms=[['Assertion','Ledningens påstående om transaktioner, saldon och upplysningar.'],['Completeness','Allt som borde ha redovisats har redovisats.'],['Existence','Det som redovisats existerar faktiskt.'],['IPE','Information Produced by the Entity.'],['RMM','Risk of Material Misstatement.'],['TOC','Test of Controls.'],['SAP','Substantive Analytical Procedures.'],['OSP','Other Substantive Procedures.'],['Management override','Ledningens möjlighet att kringgå kontroller.']] as const;